library(dplyr)
library(ggplot2)

load("dados/educacao.Rda")

ggplot(trim4, aes(x = NALF_CAT)) +
  geom_bar()

ggplot(trim4, aes(y = MAT_EJA)) +
  geom_boxplot()

ggplot(trim4, aes(y = MAT_EJA)) +
  geom_boxplot(aes(x = NALF_CAT))

# análise multivariada

# gráfico de barra
ggplot(trim4, aes(x = POP_CAT, fill = NALF_CAT)) +
  geom_bar()

ggplot(trim4, aes(x = POP_CAT, fill = NALF_CAT)) +
  geom_bar(position = "dodge")

ggplot(trim4, aes(x = POP_CAT, fill = NALF_CAT)) +
  geom_bar(position = "dodge") +
  facet_wrap(~ NALF_CAT + POP_CAT,
             ncol = 5, drop = FALSE)

# coxcomb plot
ggplot(trim4, aes(x = POP_CAT, fill = NALF_CAT)) +
  geom_bar() +
  coord_polar()

ggplot(trim4, aes(x = POP_CAT, fill = NALF_CAT)) +
  geom_bar() +
  coord_polar() +
  facet_wrap(~ NALF_CAT)


# histograma
ggplot(trim4, aes(x = MAT_EJA, fill = NALF_CAT)) +
  geom_histogram()

ggplot(trim4, aes(x = MAT_EJA, fill = NALF_CAT)) +
  geom_histogram() +
  facet_wrap(~ NALF_CAT)

# boxplot
ggplot(trim4, aes(y = MAT_EJA, x = NALF_CAT)) +
  geom_boxplot()

ggplot(trim4, aes(y = MAT_EJA, fill = NALF_CAT)) +
  geom_boxplot()

ggplot(trim4, aes(y = MAT_EJA, x = NALF_CAT,
                  fill = POP_CAT)) +
  geom_boxplot()

ggplot(trim4, aes(y = MAT_EJA, fill = POP_CAT)) +
  geom_boxplot() +
  facet_wrap(~ NALF_CAT)

# gráfico de dispersão

ggplot(trim4, aes(y = MAT_EJA, x = DEM,
                  colour = NALF_CAT)) +
  geom_point()

ggplot(trim4, aes(y = MAT_EJA, x = DEM,
                  colour = POP)) +
  geom_point()


ggplot(trim4, aes(y = MAT_FUND, x = DEM)) +
  geom_hex()

ggplot(trim4, aes(y = POP_CAT, x = MAT_FUND)) +
  geom_count()

ggplot(trim4, aes(y = POP_CAT, x = NALF_CAT)) +
  geom_count()


ggplot(trim4, aes(y = MAT_FUND, x = POP, col = NALF_CAT)) +
  geom_point() +
  scale_color_discrete(name = "Percentual de analfabetos") +
  labs(title = "Dispersão de matrículas no fundamental por população",
       subtitle = "Segundo percentual de analfabetismo",
       x = "População", y = "Demanda do Fundamental",
       caption = "Fonte: Pátio Digital (SME/SP) e Censo 2010 (IBGE)")