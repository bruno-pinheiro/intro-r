## caso preciso instalar os pacotes
# install.packages("dplyr")
# install.packages("ggplot2")

# Pacotes e dados ------------------------------------------------------------

## pacotes
library(ggplot2)
library(dplyr)

## importar os dados da aula
renda <- read.csv("dados/renda_capital_selecionadas.csv",
                  stringsAsFactors = FALSE, encoding = "UTF-8")

## visualizar estrutura
str(renda)

## verificar NAs
colSums(is.na(renda))

# 1. Selecionar variáveis ----------------------------------------------------

## Especificar colunas
renda <- renda %>%
  select(-IdadeMeses, -SitOcupacao, -RendTrabTodos,
         -RendMensalTotal, -DecRendMensalTotal,
         -DecRendTrabTodos)

renda %>%
  select(Raca, Sexo, NumPessoasFam) %>% 
  head

renda %>%
  select(Raca, Sexo, NumPessoasFam)

## Intervalo de colunas
renda %>%
  select(Sexo:NumPessoasFam) %>% 
  head

## Eliminar colunas
renda %>%
  select(-(Raca:RendTrabDemais)) %>% 
  head

## Selecionar com funções auxiliares
renda %>% 
  select(starts_with("rend")) %>% 
  head

renda %>% 
  select(ends_with("s")) %>% 
  head

renda %>% 
  select(contains("trab")) %>% 
  head

# Atividade: selecionar variáveis ---------------------------------------------

# Atividade 3
# Veja o código abaixo. Modifique-o para selecionar apenas o intervalo de
# colunas que vai de `Peso_amostral` até `NumPessoasFam`.
renda %>%
  select(-(Peso_amostral:NumPessoasFam)) %>%
  head

# Atividade 4
# Selecione apenas as variáveis `NivelInstrucao` e `RendTrabPrinc` da base de
# dados `renda`. Inclua a função `head()` no final da cadeia de comandos para
# visualizar apenas as primeiras linhas


# 2. Filtrar linhas -----------------------------------------------------------

## Com intersecção "e"
df <- renda %>% 
  filter(Sexo == "Feminino",
         Raca == "Preta",
         PosOcupacao == "Empregadores")
df %>% count(Sexo, Raca, PosOcupacao)

df <- renda %>% 
  filter(Sexo == "Feminino",
         Raca == "Preta",
         NivelInstrucao == "Superior completo")
df %>% distinct(NivelInstrucao)

## Com operador de negativa "!"
df <- renda %>% 
  filter(Sexo != "Feminino",
         Raca != "Preta",
         NivelInstrucao != "Superior completo")

df %>% count(Sexo, Raca, NivelInstrucao)

## Com união "ou" e intersecção "e"
df <- renda %>% 
  filter(Sexo == "Masculino", Raca == "Preta" | Raca == "Parda")

df %>% count(Sexo, Raca)

## Com operadores matemáticos
df <- renda %>% 
  filter(RendTrabPrinc >= 10000)


renda %>%
  filter(RendTrabPrinc < RendOutrasFontes) %>% 
  select(RendTrabPrinc, RendOutrasFontes) %>%
  head

# options(scipen = 999)
min(df$RendTrabPrinc)

## Filtrar NAs

### Manter NAS
df <- renda %>%
  filter(is.na(NumPessoasFam))
head(df$NumPessoasFam)

### Exluir NAs
df <- renda %>%
  filter(!is.na(NumPessoasFam))
head(df$NumPessoasFam)


# Atividade: filtrar observações ----------------------------------------------

# Atividade 3
# Filtre da base `renda` apenas as pessoas que fazem parte de famílias com
# 8 ou mais membros e guarde num objeto chamado `familia8`
familia8 <- renda %>% 
  filter(NumPessoasFam >= 8)

# Atividade 4
# Filtre a variável `Raca` da base `renda` para obter apenas as respostas de
# pessoas que se declaram Amarelas e guarde num objeto chamado `amarelos`
amarelos <- renda %>%
  filter(Raca == "Amarela")


# 3. Transformação e criação de variáveis

## Operações numéricas
renda <- renda %>% 
  mutate(RendMensal = RendTrabPrinc + RendTrabDemais + RendOutrasFontes,
         mediaRend = RendMensal > mean(RendMensal))

renda[2501:2506, 13:14]

## Alterar classes de variáveis


## Criar categórica a partir de numérica


# Atividade: Transformação ----------------------------------------------------

## Atividade 5: Utilize a função mutate() para criar uma variável chamada
# RendTrab com o total dos rendimentos oriundos do trabalho. Some RendTrabPrinc
# e RendTrabDemais.


## Atividade 6: Crie uma variável com a percentual da renda do trabalho
# principal RendTrab sobre a renda mensal total RendMensal. Dê a esta nova o nome
# de PesoRendTrab


# 4. Resumir estatísticas -----------------------------------------------------


# Resumir uma variável numérica
renda %>%
  summarise(mediaRendMensal = mean(RendMensal),
            medianaRendMensal = median(RendMensal),
            minRendMensal = min(RendMensal),
            maxRendMensal = max(RendMensal))

summary(renda$RendMensal)

renda %>%
  group_by(Sexo, Raca) %>%
  summarise(mediaRendMensal = mean(RendMensal),
            medianaRendMensal = median(RendMensal)) %>% 
  tidyr::gather(estat, valor, -Sexo, -Raca) %>%
  ggplot(aes(x = Sexo, y = valor, fill = estat)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~ Raca)



## Lidar com NA em resumos estatísticos


## Resumir numérica agrupada por categórica

# Atividade: sumarização ------------------------------------------------------

## Atividade 7: Calcule a média de idade por posição na ocupação. Combine as
# funções group_by() e summarise() para realizar o cálculo e nomeia a variável
# nova com mediaIdade
