## caso preciso instalar os pacotes
# install.packages("dplyr")
# install.packages("ggplo2")

# Pacotes e dados ------------------------------------------------------------

## pacotes


## importar os dados da aula


## visualizar estrutura


## verificar NAs


# 1. Selecionar variáveis ----------------------------------------------------


## Especificar colunas


## Intervalo de colunas


## Eliminar colunas


## Selecionar com funções auxiliares


# Atividade: selecionar variáveis ---------------------------------------------

# Atividade 3
# Veja o código abaixo. Modifique-o para selecionar apenas o intervalo de
# colunas que vai de `Peso_amostral` até `NumPessoasFam`.
renda %>%
  select(-(Peso_amostral:NumPessoasFam)) %>%
  head

# Atividade 4
# Selecione apenas as variáveis `NivelInstrucao` e `RendTrabPrinc` da base de
# dados `renda`. Inclua a função `head()` no final da cadeia de comandos para
# visualizar apenas as primeiras linhas


# 2. Filtrar linhas -----------------------------------------------------------

## Com intersecção "e"


## Com operador de negativa "!"


## Com união "ou" e intersecção "e"


## Com operadores matemáticos


## Filtrar NAs

### Manter NAS

### Exluir NAs


# Atividade: filtrar observações ----------------------------------------------

# Atividade 3
# Filtre da base `renda` apenas as pessoas que fazem parte de famílias com
# 8 ou mais filhos e guarde num objeto chamado `familia8`


# Atividade 4
# Filtre a variável `Raca` da base `renda` para obter apenas as respostas de
# pessoas que se declaram Amarelas e guarde num objeto chamado `amarelos`



# 3. Transformação e criação de variáveis

## Operações numéricas


## Alterar classes de variáveis


## Criar categórica a partir de numérica


# Atividade: Transformação ----------------------------------------------------

## Atividade 5: Utilize a função mutate() para criar uma variável chamada
# RendTrab com o total dos rendimentos oriundos do trabalho. Some RendTrabPrinc
# e RendTrabDemais.


## Atividade 6: Crie uma variável com a percentual da renda do trabalho
# principal RendTrab sobre a renda mensal total RendMensal. Dê a esta nova o nome
# de PesoRendTrab


# 4. Resumir estatísticas -----------------------------------------------------


# Resumir uma variável numérica


## Lidar com NA em resumos estatísticos


## Resumir numérica agrupada por categórica

# Atividade: sumarização ------------------------------------------------------

## Atividade 7: Calcule a média de idade por posição na ocupação. Combine as
# funções group_by() e summarise() para realizar o cálculo e nomeia a variável
# nova com mediaIdade
