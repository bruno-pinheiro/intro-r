## caso preciso instalar os pacotes
# install.packages("dplyr")
# install.packages("ggplo2")

# Carregar os pacotes
library(dplyr)
library(ggplot2)

## importar os dados da aula
renda <- read.csv("dados/renda_capital_selecionadas.csv",
                  stringsAsFactors = FALSE, encoding = "UTF-8")

## visualizar estrutura
str(renda)

## verificar NAs
colSums(is.na(renda))

## Resumo da aula anterior

renda <- renda %>% 
  mutate(RendTrab = RendTrabPrinc + RendTrabDemais,
         mediaTrab = factor(if_else(RendTrab > mean(RendTrab), "Sim", "Não"),
                            levels = c("Sim", "Não")),
         catRendTrab = cut(RendTrab,
                             breaks = c(-1, 511, 1531, 2551, 5111, Inf),
                             labels = c("Até 1 SM", "1 a 3 SM", "3 a 5 SM",
                                        "5 a 10 SM", "> 10 SM")),
         faixaEtaria = cut(IdadeAnos,
                           breaks = c(0, 30, 61, Inf),
                           labels = c("Jovens (até 29)",
                                      "Adultos (30 a 60)",
                                      "Idosos (> 60)")))

## Medidas de posição

renda <- renda %>% 
  mutate(DecRendTrab = recode_factor(ntile(RendTrab, 10),
                                     "1" = "D1", "2" = "D2", "3" = "D3",
                                     "4" = "D4", "5" = "D5", "6" = "D6",
                                     "7" = "D7", "8" = "D8", "9" = "D9",
                                     "10" = "D10"))

renda %>% 
  group_by(DecRendTrab) %>% 
  summarise(min = min(RendTrab),
            max = max(RendTrab),
            n = n())

# Sumarização -----------------------------------------------------------------

## lidar com NA em resumos estatísticos
renda %>% 
  summarise(mediaFam = mean(NumPessoasFam, na.rm = TRUE))


## Resumos agrupados - com group_by()
renda %>% 
  group_by(Sexo, PosOcupacao) %>% 
  summarise(min = min(RendTrab),
            media = mean(RendTrab),
            mediana = median(RendTrab),
            max = max(RendTrab),
            dp = sd(RendTrab))

summary(renda$RendTrab)
  
## Reordenar variáveis
renda %>% 
  group_by(PosOcupacao) %>% 
  summarise(media = mean(RendTrab)) %>% 
  arrange(-media)


# União de linhas e colunas ---------------------------------------------------

## unir colunas

idade <- renda %>% select(IdadeAnos)
sexo <- renda %>% select(Sexo)

idadeSexo <- cbind(idade, sexo)


## unir linhas

empregadoras <- renda %>% 
  filter(Sexo == "Feminino", PosOcupacao == "Empregadores")

empregadores <- renda %>% 
  filter(Sexo == "Masculino", PosOcupacao == "Empregadores")


empreg <- rbind(empregadoras, empregadores)




# Mesclar bases ---------------------------------------------------------------

ocupIdade <- renda %>% 
  group_by(PosOcupacao) %>% 
  summarise(mediaIdade = mean(IdadeAnos)) %>% 
  arrange(-mediaIdade)

ocupRend <- renda %>% 
  group_by(PosOcupacao) %>% 
  summarise(mediaRend = mean(RendTrab))

ocupIdade <- merge(ocupIdade,ocupRend, by = "PosOcupacao")

## Revisão geral

### A renda entre homens e mulheres no município de São Paulo é desigual?
### O que diz uma comparação por decis de renda?
### Qual 

# Comparar medidas-resumo (média)
renda %>% 
  group_by(Sexo, PosOcupacao) %>% 
  summarise(media = mean(RendTrab)) %>% 
  arrange(PosOcupacao)

# Comparar intervalos por decil
resumoDec <- renda %>%
  group_by(Sexo) %>% 
  mutate(DecRendTrab = recode_factor(ntile(RendTrab, 10),
                                     "1" = "D1", "2" = "D2", "3" = "D3",
                                     "4" = "D4", "5" = "D5", "6" = "D6",
                                     "7" = "D7", "8" = "D8", "9" = "D9",
                                     "10" = "D10")) %>% 
  group_by(Sexo, DecRendTrab) %>% 
  summarise(media = mean(RendTrab),
            min = min(RendTrab),
            max = max(RendTrab))

# Visualizar percentual de participação na renda total do município
ggplot(resumoDec) +
  geom_point(aes(x = DecRendTrab, y = media, col = Sexo),
             position = position_dodge(width = .6)) +
  geom_linerange(aes(ymin = min, ymax = max,
                     col = Sexo, x = DecRendTrab),
                 position = position_dodge(width = .6)) +
  scale_y_continuous(limits = c(0, 10000)) +
  coord_flip() +
  theme_bw()

# Analisar diferença percentual entre homens e mulheres, por decil

percRend <- renda %>% 
  group_by(DecRendTrab, Sexo) %>% 
  summarise(rendTotal = sum(RendTrab)) %>%
  ungroup() %>% 
  mutate(propRendTotal = rendTotal / sum(rendTotal))

ggplot(percRend, aes(x = DecRendTrab, y = propRendTotal, fill = Sexo)) +
  geom_bar(stat = "identity")

h <- percRend %>% 
  filter(Sexo == "Masculino") %>% 
  select(DecRendTrab, Sexo, propRendTotal)

m <- percRend %>% 
  filter(Sexo == "Feminino") %>% 
  select(DecRendTrab, Sexo, propRendTotal)

percDif <- data.frame(decil = h$DecRendTrab,
                      dif = h$propRendTotal - m$propRendTotal)

ggplot(percDif, aes(x = decil, y = dif, fill = dif < 0)) +
  geom_bar(stat = "identity") +
  coord_flip()

# ATIVIDADE: Transformação ----------------------------------------------------

## Atividade 1: Utilize a função mutate() para criar uma variável chamada
# RendTotal com a renda mensal total. Some RendTrab e RendOutrasFontes


## Atividade 2: Crie uma variável com o percentual da renda do trabalho
# RendTrab sobre a renda mensal total RendMensal. Dê a esta nova variável o nome
# de PesoRendTrab


## Atividade 3: Transforme a variável RendMensal em categórica e guarde o
# resultado numa nova variável chamada catRendMensal. Faça igual ao que foi
# feito no caso da variável catRendTrab


## Atividade 4: Compute os decis da renda mensal total RendMensal e guarde os
# resultados numa nova variável chamada catRendMensal

# Atividade: sumarização ------------------------------------------------------

## Atividade 7: Calcule a média de idade por posição na ocupação. Combine as
# funções group_by() e summarise() para realizar o cálculo e nomeie a variável
# nova com mediaIdade




