## caso preciso instalar os pacotes
# install.packages("dplyr")
# install.packages("ggplo2")

# Carregar os pacotes
library(dplyr)
library(ggplot2)

## importar os dados da aula
renda <- read.csv("dados/renda_capital_selecionadas.csv",
                  stringsAsFactors = FALSE, encoding = "UTF-8")

## visualizar estrutura
str(renda)

## verificar NAs
colSums(is.na(renda))

## Resumo da aula anterior

renda <- renda %>% 
  mutate(RendTrab = RendTrabPrinc + RendTrabDemais,
         mediaTrab = factor(if_else(RendTrab > mean(RendTrab), "Sim", "Não"),
                            levels = c("Sim", "Não")),
         catRendTrab = cut(RendTrab,
                             breaks = c(-1, 511, 1531, 2551, 5111, Inf),
                             labels = c("Até 1 SM", "1 a 3 SM", "3 a 5 SM",
                                        "5 a 10 SM", "> 10 SM")),
         faixaEtaria = cut(IdadeAnos,
                           breaks = c(0, 30, 61, Inf),
                           labels = c("Jovens (até 29)",
                                      "Adultos (30 a 60)",
                                      "Idosos (> 60)")))

## Medidas de posição


# Sumarização -----------------------------------------------------------------

## lidar com NA em resumos estatísticos

## Resumos agrupados - com group_by()

## Reordenar variáveis

# União de linhas e colunas ---------------------------------------------------

## unir colunas

idade <- renda %>% select(IdadeAnos)
sexo <- renda %>% select(Sexo)


## unir linhas

empregadoras <- renda %>% 
  filter(Sexo == "Feminino", PosOcupacao == "Empregadores")

empregadores <- renda %>% 
  filter(Sexo == "Masculino", PosOcupacao == "Empregadores")


# Mesclar bases ---------------------------------------------------------------

ocupIdade <- renda %>% 
  group_by(PosOcupacao) %>% 
  summarise(mediaIdade = mean(IdadeAnos),
            mediaRend = mean(RendTrab)) %>% 
  arrange(-mediaIdade)

ocupRend <- renda %>% 
  group_by(PosOcupacao) %>% 
  summarise(mediaRend = mean(RendTrab))

## Revisão geral

### A renda entre homens e mulheres no município de São Paulo é desigual?
### O que diz uma comparação por decis de renda?
### Qual 

# Comparar medidas-resumo (média)

# Comparar intervalos por decil


# Visualizar percentual de participação na renda total do município


# Analisar diferença percentual entre homens e mulheres, por decil






# ATIVIDADE: Transformação ----------------------------------------------------

## Atividade 1: Utilize a função mutate() para criar uma variável chamada
# RendTotal com a renda mensal total. Some RendTrab e RendOutrasFontes


## Atividade 2: Crie uma variável com o percentual da renda do trabalho
# RendTrab sobre a renda mensal total RendMensal. Dê a esta nova variável o nome
# de PesoRendTrab


## Atividade 3: Transforme a variável RendMensal em categórica e guarde o
# resultado numa nova variável chamada catRendMensal. Faça igual ao que foi
# feito no caso da variável catRendTrab


## Atividade 4: Compute os decis da renda mensal total RendMensal e guarde os
# resultados numa nova variável chamada catRendMensal

# Atividade: sumarização ------------------------------------------------------

## Atividade 7: Calcule a média de idade por posição na ocupação. Combine as
# funções group_by() e summarise() para realizar o cálculo e nomeie a variável
# nova com mediaIdade




