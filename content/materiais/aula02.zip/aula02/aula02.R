## caso preciso instalar os pacotes
# install.packages("dplyr")
# install.packages("ggplo2")

# Carregar os pacotes 
library(dplyr)
library(ggplot2)

## importar os dados da aula
load("dados/dados_aula02.Rda")

## visualizar estrutura
str(trim4)

## verificar NAs
colSums(is.na(trim4))

## visualização de variável categóricca
ggplot(trim4, aes(x = POP_CAT)) +
  geom_bar() +
  coord_flip()

## visualização de variáveis numéricas

# histograma
ggplot(trim4, aes(x = MAT)) +
  geom_histogram()

# densidade de matrículas
ggplot(trim4, aes(x = MAT)) +
  geom_density()

# densidade de demanda
ggplot(trim4, aes(x = DEM)) +
  geom_density()

# boxplot de demanda
ggplot(trim4, aes(y = DEM)) +
  geom_boxplot()

## análise biavariada: numérica versus categórica

## categorias de população versus demanda

# boxplot
ggplot(trim4, aes(x = POP_CAT, y = DEM)) +
  geom_boxplot()

# histograma
ggplot(trim4, aes(x = DEM, fill = POP_CAT)) +
  geom_histogram()

# resumo da relação entre demanda por matrículas e população
prop <- trim4 %>%
  group_by(POP_CAT) %>%
  summarise(DEM_PROP = sum(DEM) / sum(POP))

ggplot(prop, aes(x = POP_CAT, y = DEM_PROP)) +
  geom_bar(stat = "identity") +
  geom_label(aes(label = round(DEM_PROP, 3)))


## categorias de percentual de analfabetos versus matrículas

# boxplot
ggplot(trim4, aes(x = NALF_CAT, y = MAT)) +
  geom_boxplot()

# histograma - com facetas
ggplot(trim4, aes(x = MAT)) +
  geom_histogram() +
  facet_wrap(~ NALF_CAT)


## análise bivariada: numérica versus numérica

# gráfico de dispersão (scatterplot)

## população versus demanda
ggplot(trim4, aes(x = POP, y = DEM)) +
  geom_point()

## população versus matrícula
ggplot(trim4, aes(x = POP, y = MAT)) +
  geom_point()


## demanda versus matrícula, colorido por categoria de percentual de analfabetos 
p1 <- ggplot(trim4, aes(x = DEM, y = MAT, colour = NALF_CAT))
p1 + geom_point()

## adicionando transparência
p1 + geom_point(alpha = .4)

## adicionando faceta por cateogoria de população
p1 +
  geom_point(alpha = .4) +
  facet_grid(~ POP_CAT)

## análise temporal
ggplot(dem_educ, aes(x = MAT, y = DEM, colour = NALF_CAT)) +
  geom_point(alpha = .5) +
  facet_wrap(~ MES_REF + NALF_CAT, ncol = 4, drop = FALSE)

