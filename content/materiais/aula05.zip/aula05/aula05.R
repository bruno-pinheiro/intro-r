## caso preciso instalar os pacotes
# install.packages("dplyr")
# install.packages("ggplo2")

# Carregar os pacotes

## importar os dados da aula


## visualizar estrutura

## verificar NAs


# All verbs work similarly:
# The first argument is a data frame.
# The subsequent arguments describe what to do with the data frame, using the variable names (without quotes).
# The result is a new data frame.


# Atividade: Filtro e seleção -------------------------------------------------

## Atividade 1: Utilize as funções `filter()` para criar um subconjunto da base
# de dados contento as observações referentes a mulheres brancas e pretas com
# ensino superior. Utilize o a função `head()` para ver apenas as primeiras
# linhas do resultado

## Atividade 2: Agora adicione uma porção de código para realizar o filtro
# feito acima e selecionar as variávels `Raca`, `RendTrabPrinc`,
# `RendTrabDemais`. Utilize a função `select()` e guarde o resultado num
# objeto chamado renda_fem_raca



# Transformação e criação de variáveis ----------------------------------------

## Operações numéricas


## Alterar classes de variáveis


## Criar categórica a partir de numérica


## Agregar novas colunas

# Diferença de classes e ordenamento (factor x character)



# Atividade: Transformação ----------------------------------------------------

## Atividade 5: Utilize a função mutate() para criar uma variável chamada
# RendTrab com o total dos rendimentos oriundos do trabalho. Some RendTrabPrinc
# e RendTrabDemais.


## Atividade 6: Crie uma variável com a percentual da renda do trabalho
# principal RendTrab sobre a renda mensal total RendMensal. Dê a esta nova o nome
# de PesoRendTrab


## Resumir estatísticas

# lidar com NA em resumos estatísticos


## Resumos agrupados


# Atividade: sumarização ------------------------------------------------------

## Atividade 7: Calcule a média de idade por posição na ocupação. Combine as
# funções group_by() e summarise() para realizar o cálculo e nomeie a variável
# nova com mediaIdade


## Reordenar variáveis



## Juntar tudo



# Manipular títulos e eixos do gráfico

