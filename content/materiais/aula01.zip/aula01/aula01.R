# Primeiros comandos ----------------------------------------------------------

# adição
1 + 1 

# subtração
4 - 2

# multiplicação
2 * 3 

# divisão
5 / 2 

# potência
4 ^ 2 

# criar vetores
x <- c(1, 2, 3, 4)
y <- c(2, 3, 5, 6)

# visualizar vetores
x
y

# somar os vetores
x + y

# Instalar pacotes ------------------------------------------------------------

## do CRAN
# install.packages("tidyverse")

## do github com o pacote devtools
# install.packages("devtools")
# devtools::install_github("hadley/tidyverse")

## Carregar pacote
# library(devtools)
# install_github("hadley/tidyverse")

# Importar dados no R ---------------------------------------------------------
df <- read.csv("dados/aula01.csv", stringsAsFactors = FALSE)

# Checar os dados -------------------------------------------------------------

# Visualizar o começo dos dados
head(df)

# Visualizar o fim dos dados
tail(df)

# Usando o argumento n para definir número de linhas
head(df, n = 2)
tail(df, n = 2)

# destacar que o argumento é opcional
# head(df, 3)

# Verificar a estrutura dos dados ---------------------------------------------
str(df)

# Investigar presença de NAs --------------------------------------------------

## Forma direta
is.na(head(df))

## Forma em etapas, para explicar o uso das funções
## Destacar os objetos do R

# guardas as primeiras seis linhas
linhas <- head(df)
# visualizar
linhas

# investigar presença de NAs
is.na(linhas)

# resumir
colSums(is.na(df))

# Análise descritiva de dados -------------------------------------------------

## Carregar pacotes
library(dplyr) # para manipular os dados
library(ggplot2) # para visualizar os dados

## visualizar nomes das variáveis
names(df)

## Análise da distribuição de Raca --------------------------------------------

## Falar da frequência absoluta e relativa
## Explicar o pipe
df %>% count(Raca)

## Exemplificar o pipe calculando a frequência relativa
df %>%
  # contar as categorias
  count(Raca) %>%
  # calcular a frequência relativa
  mutate(prop = prop.table(n))

## Visualizar a distribuição de Raca ------------------------------------------

# calcular as frequências
freq <- df %>%
  count(Raca) %>%
  mutate(prop = prop.table(n))
# visualizar
freq

# Destaca as camadas do gráfico
## ------------------------------------------------------------------------
ggplot(freq, aes(x = Raca, y = prop)) + # cria o canvas e define estética
  geom_bar(stat = "identity") # coloca o gráfico de barras

# Exemplicar o esquema de camadas adicionando os rótulos
## ------------------------------------------------------------------------
ggplot(freq, aes(x = Raca, y = prop, label = round(prop, 4))) + # cria o canvas
  geom_bar(stat = "identity") + # coloca o gráfico de barras
  geom_label() # coloca o rótulo


## Distribuição de quantitativa discreta --------------------------------------

## Distribuição de NumPessoasFam ----------------------------------------------
summary(df$NumPessoasFam)

## ------------------------------------------------------------------------
# calcular as frequẽncias
freq <- df %>%
  # contar os valores
  count(NumPessoasFam) %>%
  # calcular a frequência relativa
  mutate(prop = prop.table(n))

# plotar o gráfico
ggplot(freq, aes(x = NumPessoasFam, y = prop)) +
  geom_bar(stat = "identity")

## Distribuição de quantitativa contínua  -------------------------------------

## Distribuição de RendTrabPrinc ----------------------------------------------
summary(df$RendTrabPrinc)

## ------------------------------------------------------------------------
ggplot(df, aes(x = RendTrabPrinc)) +
  geom_histogram()

## ------------------------------------------------------------------------
ggplot(df, aes(x = RendTrabPrinc)) +
  geom_histogram(bins = 25)  +
  scale_x_continuous(limits = c(0, 10000))

## ------------------------------------------------------------------------
ggplot(df, aes(y = RendTrabPrinc)) +
  geom_boxplot() +
  scale_y_continuous(limits = c(0, 10000))

## help(read.csv)

## ------------------------------------------------------------------------
?read.csv

# EXERCÍCIO 01 ------------------------------------------------------------

## ------------------------------------------------------------------------
# # calcular as frequências
# freq <- df %>%
#   count(___) %>%
#   mutate(prop = prop.table(n))

## ------------------------------------------------------------------------
# # visualizar os dados
# ggplot(___, aes(x = ___, y = prop, label = round(prop, 4))) +
#   geom_bar(stat = "identity") +
#   geom_label()

## ------------------------------------------------------------------------
# cole ou digite abaixo o seu código

# EXERCÍCIO 02 ------------------------------------------------------------

## ------------------------------------------------------------------------
ggplot(df, aes(x = IdadeAnos)) +
  geom_histogram()

## ------------------------------------------------------------------------
# Cole aqui o código acima e faça as modificações necessárias


## ------------------------------------------------------------------------
# Cole aqui o código acima e faça as modificações necessárias


# EXERCÍCIO 03 ------------------------------------------------------------

## ------------------------------------------------------------------------
ggplot(df, aes(x = Sexo, y = IdadeAnos)) +
  geom_boxplot()

## ------------------------------------------------------------------------
# Cole aqui o código acima e faça as modificações necessárias



